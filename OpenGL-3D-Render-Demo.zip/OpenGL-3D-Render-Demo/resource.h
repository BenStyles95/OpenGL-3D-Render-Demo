//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Nucleus.rc
//
#define IDD_INIT                        102
#define IDC_FILENAME                    1001
#define IDC_DISTX                       1003
#define IDC_DISTY                       1009
#define IDC_DISTZ                       1010
#define IDC_ANGLEX                      1011
#define IDC_ANGLEY                      1012
#define IDC_ANGLEZ                      1013
#define IDC_LIGHTX                      1014
#define IDC_LIGHTY                      1015
#define IDC_LIGHTZ                      1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
